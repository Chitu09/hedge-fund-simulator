# 🏦 Multi-Strategy Hedge Fund Simulation — Indian Markets

> 3rd Year College Project | Quantitative Finance | NSE Real Data | Streamlit Dashboard

---

## What This Project Does

Simulates a **multi-strategy hedge fund** on real NSE (National Stock Exchange) data using four independent trading strategies, combined via Risk Parity portfolio construction.

| Strategy | Type | Signal |
|---|---|---|
| **Momentum** | Long/Short | 12-1 month cross-sectional ranking |
| **Mean Reversion** | Long/Short | 20-day Bollinger Band z-score |
| **Statistical Arbitrage** | Pairs Trading | Engle-Granger cointegration |
| **Volatility Targeting** | Long-only | Inverse-vol risk parity |

---

## Project Structure

```
hedge_fund_app/
├── app.py              ← Main Streamlit dashboard
├── data.py             ← NSE data download & cleaning (yfinance)
├── strategies.py       ← All 4 strategy implementations
├── analytics.py        ← Performance metrics & walk-forward
├── requirements.txt    ← Python dependencies
├── .streamlit/
│   └── config.toml     ← Dark theme configuration
└── README.md           ← This file
```

---

## ▶️ Run Locally

### Step 1: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run the app
```bash
streamlit run app.py
```

The app will open at `http://localhost:8501` in your browser.  
It downloads ~6 years of real NSE data on first run (~30 seconds).

---

## 🚀 Deploy on Streamlit Cloud (Free)

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Hedge fund simulation - initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hedge-fund-india.git
git push -u origin main
```

### Step 2: Deploy
1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Sign in with GitHub
3. Click **"New app"**
4. Select your repository → branch: `main` → file: `app.py`
5. Click **Deploy** — it will be live in ~2 minutes!

Your app URL will be: `https://YOUR_USERNAME-hedge-fund-india-app-XXXXX.streamlit.app`

---

## Data

- **Source:** Yahoo Finance via `yfinance` (NSE suffix `.NS`)
- **Prices:** Split-adjusted, dividend-adjusted closing prices
- **Benchmark:** NIFTY 50 Index (`^NSEI`)
- **Universe:** 20 NIFTY 50 large-cap stocks across 8 sectors
- **Period:** Jan 2018 – Dec 2023 (configurable in sidebar)
- **No synthetic data** is used anywhere

---

## References

1. Jegadeesh & Titman (1993) — Momentum
2. DeBondt & Thaler (1985) — Mean Reversion
3. Gatev, Goetzmann & Rouwenhorst (2006) — Pairs Trading
4. Qian (2005), Asness et al. (2012) — Risk Parity
5. Engle & Granger (1987) — Cointegration
